package com.example.concesionario_proyect.persistency.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = "vehiculo")
public class Vehiculo {
    @Id
    @Size(max = 15)
    @Column(name = "placa", nullable = false, length = 15)
    private String placa;

    @Column(name = "marca_id", columnDefinition = "int UNSIGNED not null")
    private Long marcaId;

    @Column(name = "cilindraje_id", columnDefinition = "int UNSIGNED not null")
    private Long cilindrajeId;

    @Column(name = "modelo_id", columnDefinition = "int UNSIGNED not null")
    private Long modeloId;

    @NotNull
    @Column(name = "precio", nullable = false, precision = 10, scale = 2)
    private BigDecimal precio;

}