package com.example.concesionario_proyect.dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;
@Getter
@Setter
public class VendedorDTO implements Serializable {
    private int cedula;
    private String nombre;
    private String apellido;
    private String email;
    private String direccion;
    private String telefono;
    private LocalDateTime fechaventa = LocalDateTime.now();

}
