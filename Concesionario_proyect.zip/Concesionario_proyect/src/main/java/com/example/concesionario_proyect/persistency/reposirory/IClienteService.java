package com.example.concesionario_proyect.persistency.reposirory;

import com.example.concesionario_proyect.infraesctutura.Result;
import com.example.concesionario_proyect.persistency.entity.Cliente;
import io.vavr.control.Either;

import java.util.List;

public interface IClienteService {
    Either <Result.failure, List<Cliente>> findAll();
    Either<Result.failure, Cliente> findById(Integer id);
    Either<Result.failure, Cliente> save(Cliente cliente);
    Either<Result.failure, Cliente> update(Cliente cliente);
    Either<Result.failure, Cliente> delete(Integer id);
}
