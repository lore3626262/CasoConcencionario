package com.example.concesionario_proyect.dto;

public class VehiculoDTO {
    private int placa;
    private int idmarca;
    private int cilindraje;
    private int modeloid;
    private double precio;
}
