package com.example.concesionario_proyect.api;

import com.example.concesionario_proyect.bussines.interfaces.GeneralService;
import com.example.concesionario_proyect.persistency.entity.Cliente;
import com.example.concesionario_proyect.persistency.reposirory.IClienteService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/Cliente")


public class ClienteController extends GeneralController<Cliente> {
private final IClienteService clienteService;

    public ClienteController(IClienteService clienteService ) {
        super(clienteService);
        this.clienteService = clienteService;

    }
}
