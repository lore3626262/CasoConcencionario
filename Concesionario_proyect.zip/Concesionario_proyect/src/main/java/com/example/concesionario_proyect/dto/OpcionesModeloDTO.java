package com.example.concesionario_proyect.dto;

public class OpcionesModeloDTO {
    private int idopciones;
    private String nombre;
    private String descripcion;
}
