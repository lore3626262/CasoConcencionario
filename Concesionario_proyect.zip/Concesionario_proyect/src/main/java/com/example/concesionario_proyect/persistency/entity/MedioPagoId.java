package com.example.concesionario_proyect.persistency.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.Hibernate;

import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class MedioPagoId implements Serializable {
    private static final long serialVersionUID = 6264532916364235662L;
    @Column(name = "idMedio_pago", columnDefinition = "int UNSIGNED not null")
    private Long idmedioPago;

    @Column(name = "VEHICULO_USADO_idVEHICULO_USADO", columnDefinition = "int UNSIGNED not null")
    private Long vehiculoUsadoIdvehiculoUsado;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        MedioPagoId entity = (MedioPagoId) o;
        return Objects.equals(this.idmedioPago, entity.idmedioPago) &&
                Objects.equals(this.vehiculoUsadoIdvehiculoUsado, entity.vehiculoUsadoIdvehiculoUsado);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idmedioPago, vehiculoUsadoIdvehiculoUsado);
    }

}