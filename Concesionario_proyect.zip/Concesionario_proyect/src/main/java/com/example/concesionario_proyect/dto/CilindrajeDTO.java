package com.example.concesionario_proyect.dto;

public class CilindrajeDTO {
    private int idcilindraje;
    private int n_cilindraje;
}
