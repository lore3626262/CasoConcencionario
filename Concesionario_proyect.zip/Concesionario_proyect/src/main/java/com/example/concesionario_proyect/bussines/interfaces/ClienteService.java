package com.example.concesionario_proyect.bussines.interfaces;

import com.example.concesionario_proyect.infraesctutura.Result;
import com.example.concesionario_proyect.persistency.entity.Cliente;
import io.vavr.control.Either;

import java.util.List;

public class ClienteService implements GeneralService<Cliente> {
    @Override
    public Either<Result.failure, List<Cliente>> findAll() {
        return null;
    }

    @Override
    public Either<Result.failure, Result.id> findById(int id) {
        return null;
    }

    @Override
    public Either<Result.failure, Result.id> save(Cliente dto) {
        return null;
    }

    @Override
    public Either<Result.failure, Result.id> update(Cliente dto) {
        return null;
    }

    @Override
    public Either<Result.failure, Result.id> delete(Cliente dto) {
        return null;
    }
}
