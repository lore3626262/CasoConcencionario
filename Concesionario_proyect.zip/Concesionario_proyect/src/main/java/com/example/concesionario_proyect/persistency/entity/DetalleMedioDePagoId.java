package com.example.concesionario_proyect.persistency.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.Hibernate;

import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class DetalleMedioDePagoId implements Serializable {
    private static final long serialVersionUID = -319625790540555570L;
    @Column(name = "Medio_pago_VEHICULO_USADO_idVEHICULO_USADO", columnDefinition = "int UNSIGNED not null")
    private Long medioPagoVehiculoUsadoIdvehiculoUsado;

    @Column(name = "Medio_pago_idMedio_pago", columnDefinition = "int UNSIGNED not null")
    private Long medioPagoIdmedioPago;

    @Column(name = "VENTA_n_factura", columnDefinition = "int UNSIGNED not null")
    private Long ventaNFactura;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        DetalleMedioDePagoId entity = (DetalleMedioDePagoId) o;
        return Objects.equals(this.ventaNFactura, entity.ventaNFactura) &&
                Objects.equals(this.medioPagoVehiculoUsadoIdvehiculoUsado, entity.medioPagoVehiculoUsadoIdvehiculoUsado) &&
                Objects.equals(this.medioPagoIdmedioPago, entity.medioPagoIdmedioPago);
    }

    @Override
    public int hashCode() {
        return Objects.hash(ventaNFactura, medioPagoVehiculoUsadoIdvehiculoUsado, medioPagoIdmedioPago);
    }

}