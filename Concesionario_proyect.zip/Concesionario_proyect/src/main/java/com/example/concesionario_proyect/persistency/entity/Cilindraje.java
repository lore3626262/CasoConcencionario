package com.example.concesionario_proyect.persistency.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "cilindraje")
public class Cilindraje {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idCilindraje", nullable = false)
    private Integer id;

    @Column(name = "n_cilindraje")
    private Integer nCilindraje;

}