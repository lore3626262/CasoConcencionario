package com.example.concesionario_proyect.persistency.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = "modelo")
public class Modelo {
    @Id
    @Column(name = "idModelo", columnDefinition = "int UNSIGNED not null")
    private Long id;

    @Column(name = "opciones_modelo_id", columnDefinition = "int UNSIGNED not null")
    private Long opcionesModeloId;

    @Column(name = "precio_opcion", precision = 10, scale = 2)
    private BigDecimal precioOpcion;

}