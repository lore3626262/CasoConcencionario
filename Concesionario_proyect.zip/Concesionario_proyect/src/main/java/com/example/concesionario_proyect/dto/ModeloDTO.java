package com.example.concesionario_proyect.dto;

public class ModeloDTO {
    private int idModelo;
    private String opcionesmodelo;
    private float precioopcion;
}
