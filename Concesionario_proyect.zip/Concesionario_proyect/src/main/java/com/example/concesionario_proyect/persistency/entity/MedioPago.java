package com.example.concesionario_proyect.persistency.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "medio_pago")
public class MedioPago {
    @EmbeddedId
    private MedioPagoId id;

    @Size(max = 50)
    @Column(name = "tipo", length = 50)
    private String tipo;

    @Size(max = 255)
    @Column(name = "descripcion")
    private String descripcion;

}