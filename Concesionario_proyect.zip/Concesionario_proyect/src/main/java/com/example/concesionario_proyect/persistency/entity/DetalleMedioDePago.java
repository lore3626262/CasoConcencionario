package com.example.concesionario_proyect.persistency.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "detalle_medio_de_pago")
public class DetalleMedioDePago {
    @EmbeddedId
    private DetalleMedioDePagoId id;

    @Column(name = "total", columnDefinition = "int UNSIGNED")
    private Long total;

}