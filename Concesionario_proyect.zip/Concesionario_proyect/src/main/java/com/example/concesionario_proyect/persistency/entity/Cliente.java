package com.example.concesionario_proyect.persistency.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "cliente")
public class Cliente {
    @Id
    @Column(name = "Cedula", nullable = false)
    private Integer id;

    @Size(max = 25)
    @Column(name = "nombre", length = 25)
    private String nombre;

    @Size(max = 25)
    @Column(name = "apellidos", length = 25)
    private String apellidos;

    @Size(max = 100)
    @Column(name = "email", length = 100)
    private String email;

    @Size(max = 255)
    @Column(name = "direccion")
    private String direccion;

    @Size(max = 10)
    @Column(name = "telefono", length = 10)
    private String telefono;

}