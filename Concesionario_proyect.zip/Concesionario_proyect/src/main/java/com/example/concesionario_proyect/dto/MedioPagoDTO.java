package com.example.concesionario_proyect.dto;

public class MedioPagoDTO {
    private int idmediopago;
    private String vehiculousado;
    private String tipo;
    private String descripcion;
}
