package com.example.concesionario_proyect.dto;

import java.time.LocalDateTime;

public class VentaDTO {
    private int nfactura;
    private int vendedorcedula;
    private int clientecedula;
    private int preciototal;
    private LocalDateTime fechacesion = LocalDateTime.now();

}
