package com.example.concesionario_proyect.dto;

public class DetalleMedioDePago {
    private int pagovehiculousado;
    private int mediodepago;
    private int nfactura;
    private int  total;
}
