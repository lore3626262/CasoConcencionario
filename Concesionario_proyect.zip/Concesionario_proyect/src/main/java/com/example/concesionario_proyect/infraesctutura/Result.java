package com.example.concesionario_proyect.infraesctutura;

public interface Result {
    interface failure{String message();}
    record generalface(String message) implements failure{}

    interface identificador{String id();}
    record id(String id) implements identificador{}
}
