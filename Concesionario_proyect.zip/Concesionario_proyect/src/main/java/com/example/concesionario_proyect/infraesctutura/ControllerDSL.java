package com.example.concesionario_proyect.infraesctutura;

import io.vavr.control.Either;
import jdk.jfr.Enabled;
import org.apache.coyote.Response;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public abstract class ControllerDSL {

    protected <R>ResponseEntity<?> execute(Either<Result.failure, R> result) {
        return result.isRight()?new ResponseEntity<>(result.get(), HttpStatus.OK) : new ResponseEntity<>(result.get(), HttpStatus.BAD_REQUEST);

    }

    protected ResponseEntity<byte[]> executbyte(Either<Result.failure,byte[] > result) {
        return result.isRight()?new ResponseEntity<>(result.get(), HttpStatus.OK) : new ResponseEntity<>(result.get(), HttpStatus.BAD_REQUEST);

    }
}
