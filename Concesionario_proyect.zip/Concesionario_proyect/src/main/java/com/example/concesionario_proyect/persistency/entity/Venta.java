package com.example.concesionario_proyect.persistency.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@Entity
@Table(name = "venta")
public class Venta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "n_factura", columnDefinition = "int UNSIGNED not null")
    private Long id;

    @Column(name = "vendedor_cedula", columnDefinition = "int UNSIGNED not null")
    private Long vendedorCedula;

    @Column(name = "cliente_cedula", columnDefinition = "int UNSIGNED not null")
    private Long clienteCedula;

    @Column(name = "precio_total", precision = 10, scale = 2)
    private BigDecimal precioTotal;

    @Column(name = "fecha")
    private LocalDate fecha;

}