package com.example.concesionario_proyect.api;

import com.example.concesionario_proyect.bussines.interfaces.GeneralService;
import com.example.concesionario_proyect.infraesctutura.ControllerDSL;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

public abstract class  GeneralController<T> extends ControllerDSL {
    private final GeneralService<T> service;


    protected GeneralController(GeneralService<T> service) {
        this.service = service;
    }

    @GetMapping

    public ResponseEntity<?> getAll() {
        return execute(service.findAll());
    }

    @PostMapping
    public ResponseEntity<?> save(@RequestBody T entity) {
        return execute(service.save(entity));
    }

    @PutMapping
    public ResponseEntity<?> update(@RequestBody T entity) {
        return execute(service.update(entity));
    }

    @DeleteMapping

    public ResponseEntity<?> delete(@RequestBody T entity) {
        return execute(service.delete(entity));
    }

}
