package com.example.concesionario_proyect.bussines.interfaces;
import com.example.concesionario_proyect.infraesctutura.Result;
import io.vavr.control.Either;

import java.util.List;

public interface GeneralService <T>{
    Either <Result.failure, List<T>> findAll();
    Either<Result.failure, Result.id> findById(int id);//select por id
    Either<Result.failure, Result.id> save(T dto);// insert
    Either<Result.failure, Result.id> update(T dto);
    Either<Result.failure, Result.id> delete(T dto);


}