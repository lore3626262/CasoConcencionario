package com.example.concesionario_proyect.persistency.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@Entity
@Table(name = "vehiculo_usado")
public class VehiculoUsado {
    @Id
    @Size(max = 15)
    @Column(name = "placa", nullable = false, length = 15)
    private String placa;

    @Column(name = "modelo_id", columnDefinition = "int UNSIGNED not null")
    private Long modeloId;

    @Column(name = "marca_id", columnDefinition = "int UNSIGNED not null")
    private Long marcaId;

    @Column(name = "cliente_cedula", columnDefinition = "int UNSIGNED not null")
    private Long clienteCedula;

    @Column(name = "precio_tasacion", precision = 10, scale = 2)
    private BigDecimal precioTasacion;

    @Column(name = "fecha_cesion")
    private LocalDate fechaCesion;

}