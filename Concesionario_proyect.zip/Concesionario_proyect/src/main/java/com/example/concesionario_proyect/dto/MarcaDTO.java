package com.example.concesionario_proyect.dto;

public class MarcaDTO {
    private int idMarca;
    private String nombre;
}
