package com.example.concesionario_proyect.persistency.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.Hibernate;

import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class DetalleVentaId implements Serializable {
    private static final long serialVersionUID = -5530837205866759299L;
    @Column(name = "venta_n_factura", columnDefinition = "int UNSIGNED not null")
    private Long ventaNFactura;

    @Size(max = 15)
    @NotNull
    @Column(name = "vehiculo_placa", nullable = false, length = 15)
    private String vehiculoPlaca;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        DetalleVentaId entity = (DetalleVentaId) o;
        return Objects.equals(this.ventaNFactura, entity.ventaNFactura) &&
                Objects.equals(this.vehiculoPlaca, entity.vehiculoPlaca);
    }

    @Override
    public int hashCode() {
        return Objects.hash(ventaNFactura, vehiculoPlaca);
    }

}