package com.example.concesionario_proyect.dto;

public class ClienteDTO {
    private int cedula;
    private String nombre;
    private String apellido;
    private String email;
    private String direccion;
    private String telefono;
}
