package com.example.concesionario_proyect.persistency.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "opciones_modelo")
public class OpcionesModelo {
    @Id
    @Column(name = "idOpciones_Modelo", columnDefinition = "int UNSIGNED not null")
    private Long id;

    @Size(max = 50)
    @Column(name = "nombre", length = 50)
    private String nombre;

    @Size(max = 255)
    @Column(name = "descripcion")
    private String descripcion;

}