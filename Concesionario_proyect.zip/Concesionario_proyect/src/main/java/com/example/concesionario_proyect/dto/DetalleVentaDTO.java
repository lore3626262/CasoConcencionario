package com.example.concesionario_proyect.dto;

public class DetalleVentaDTO {
    private int n_factura;
    private String vehiculoplaca;
}
