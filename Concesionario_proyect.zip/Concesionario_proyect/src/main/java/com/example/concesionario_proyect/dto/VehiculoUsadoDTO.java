package com.example.concesionario_proyect.dto;

import java.time.LocalDateTime;

public class VehiculoUsadoDTO {
        private int placa;
        private int modeloid;
        private int idmarca;
        private int cedula;
        private int preciotasacion;
        private LocalDateTime fechacesion = LocalDateTime.now();
    ;

}
