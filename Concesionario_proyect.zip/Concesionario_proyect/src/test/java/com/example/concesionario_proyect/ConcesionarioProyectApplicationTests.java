package com.example.concesionario_proyect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConcesionarioProyectApplicationTests {

    @Test
    void contextLoads() {
    }

}
